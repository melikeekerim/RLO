RLO Master Template
========================

Update: 20201214
Author: Aaron Fecowycz

Modification of HTML template to modify structure of navigation panel and inclusion of new ARIA current page labels. Reworking of resources section to create ARIA labels for active panel including associated JavaScript. Minor modification of associated CSS rules. 

Update: 20201116
Author: Aaron Fecowycz

Description:

Removal of bootstrap theme css and theme.css.map.min files and linkage within HTML files, modification to the bootstrap css and the main css to improve contrast ratios to meet WCAG 2.1 AA requirements.

Update: 20201001
Author: Aaron Fecowycz

Description:

Modification to Aria labels of the main menu and modification to privacy settings modal. There's a couple of CSS modifications to increase the contrast ratio of a couple of elements.

Update: 20200218
Author: Aaron Fecowycz

Description:

Addition of privacy controls which enable the user to accept or reject the use of cookies, local storage and or web tracking. These technologies are not enabled by default and require the user to actively accept their use before attempting to utilise within the resource.

There is an example activity which works in conjunction with these permissions.

Date: 20190206
Author: Aaron Fecowycz


Description:

RLO Master Template with example audio narration, images, and video (including subtitles)
